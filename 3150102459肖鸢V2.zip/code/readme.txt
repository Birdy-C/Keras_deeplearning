Mnist_lenet.py :Trains a lenet on the MNIST dataset. The result is saved in the document "lenet_mnist_iter_xy.h5" .
get_picture.py :Read the picture "number.jpg" and put out the prediction.
lenet_accuracy.py :calculate the accuracy of lenet
lenet_featuremap.py :put out the detail with featuremap

"lenet_mnist_iter_xy _ 50.h5"&"lenet_mnist_iter_xy _ 500.h5" in document is trained with nb_epoch = 50 &500 , use data_augmentation